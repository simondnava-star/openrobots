import json
import unittest

from openrobots.core import RobotCommand
from openrobots.mqtt_adapter import MqttRobot, decode_state, encode_command


class MqttAdapterTests(unittest.TestCase):
    def test_encode_command_is_json(self):
        payload = encode_command(RobotCommand("move", {"speed": 0.1}))
        self.assertEqual(
            json.loads(payload), {"name": "move", "parameters": {"speed": 0.1}}
        )

    def test_decode_state_parses_json(self):
        self.assertEqual(decode_state(b'{"battery": 87}'), {"battery": 87})

    def test_decode_state_keeps_plain_text(self):
        self.assertEqual(decode_state(b"hello"), {"raw": "hello"})

    def test_topics(self):
        robot = MqttRobot("localhost", base_topic="openrobots/bot1")
        self.assertEqual(robot.command_topic, "openrobots/bot1/commands")
        self.assertEqual(robot.state_topic, "openrobots/bot1/state")


if __name__ == "__main__":
    unittest.main()
