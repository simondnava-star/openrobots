# OpenRobots

An extensible, simulator-first Python framework for connecting different
kinds of robots through one consistent interface. This starter project
includes a harmless simulator, not real robot drivers or unsupervised
physical control.

## Requirements

Python 3.11 or newer.

## Install and test

    python -m pip install -e .
    python -m unittest discover -s tests

## Run with Docker (Windows)

Double-click `launch-docker.bat`. It checks Docker Desktop is running,
builds the image, and runs the demo (`demo.py`) inside the container.
From a command prompt in this folder:

- `launch-docker.bat test` — run the tests in Docker
- `launch-docker.bat dashboard` — run the web dashboard in Docker,
  then open http://localhost:8080

## Dashboard

`dashboard.py` serves a small web dashboard (no extra packages needed)
showing every registered robot, its live state, connect/disconnect
buttons, and a command form. Commands still go through the hub's
CommandPolicy. Run it directly with `python dashboard.py`, or in Docker
with `launch-docker.bat dashboard`.

## MQTT robots

`openrobots.mqtt_adapter.MqttRobot` connects a robot through an MQTT
broker with JSON payloads: commands go to `<base_topic>/commands` and
state comes back on `<base_topic>/state`. It needs the optional
paho-mqtt package:

    python -m pip install -e ".[mqtt]"

Set `OPENROBOTS_MQTT_HOST` (and optionally `OPENROBOTS_MQTT_PORT`)
before starting the dashboard to register an MQTT robot alongside the
simulator.

## Quick start

    import asyncio
    from openrobots import CommandPolicy, RobotCommand, RobotHub, SimulatedRobot

    async def main():
        policy = CommandPolicy(
            allowed_commands=frozenset({"stop", "move"}),
            numeric_limits={"speed": 0.25},
        )
        hub = RobotHub(policy)
        robot = SimulatedRobot()
        hub.register("demo", robot)

        await hub.connect("demo")
        result = await hub.execute(
            "demo", RobotCommand("move", {"speed": 0.1})
        )
        print(result)
        await hub.disconnect("demo")

    asyncio.run(main())

## Add a robot integration

Implement the `RobotAdapter` interface (`connect`, `disconnect`,
`get_state`, and `execute`) and register it with `RobotHub`. Keep
vendor-specific transport and command translation inside the adapter.

The default command policy allows only `stop`. Additional commands must be
explicitly enabled. Numeric limits are generic checks, not a substitute
for device-specific safety procedures, hardware interlocks, emergency
stops, testing in a controlled environment, and human supervision.
The included simulator is the only adapter supplied.
