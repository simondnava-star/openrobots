"""A tiny zero-dependency web dashboard for a RobotHub.

Serves one HTML page plus a small JSON API:

    GET  /                              the dashboard page
    GET  /api/robots                    {robot_id: state, ...}
    POST /api/robots/<id>/connect
    POST /api/robots/<id>/disconnect
    POST /api/robots/<id>/command       {"name": "move", "parameters": {...}}

Commands still go through the hub's CommandPolicy, so the dashboard
cannot send anything the policy forbids.
"""

from __future__ import annotations

import asyncio
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import unquote, urlparse

from .core import RobotCommand, RobotHub

_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>OpenRobots Dashboard</title>
<style>
  body { font-family: system-ui, sans-serif; margin: 2rem; background: #0f1420; color: #e8ecf3; }
  h1 { font-size: 1.4rem; }
  .card { background: #1a2233; border: 1px solid #2b3852; border-radius: 10px; padding: 1rem; margin: 1rem 0; max-width: 560px; }
  .card h2 { margin: 0 0 .5rem; font-size: 1.1rem; }
  pre { background: #0b0f18; padding: .6rem; border-radius: 6px; overflow-x: auto; }
  button { background: #2f6fed; color: white; border: 0; border-radius: 6px; padding: .4rem .8rem; cursor: pointer; margin-right: .4rem; }
  button.secondary { background: #3a465f; }
  input, select { background: #0b0f18; color: #e8ecf3; border: 1px solid #2b3852; border-radius: 6px; padding: .35rem; }
  .err { color: #ff8a8a; }
</style>
</head>
<body>
<h1>OpenRobots Dashboard</h1>
<div id="robots">Loading...</div>
<script>
async function api(path, body) {
  const res = await fetch(path, body ? {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)} : {});
  return res.json();
}
async function refresh() {
  const data = await api('/api/robots');
  const box = document.getElementById('robots');
  box.innerHTML = '';
  for (const [id, state] of Object.entries(data)) {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `<h2>${id}</h2><pre>${JSON.stringify(state, null, 2)}</pre>
      <button onclick="act('${id}','connect')">Connect</button>
      <button class="secondary" onclick="act('${id}','disconnect')">Disconnect</button>
      <p>
        <select id="cmd-${id}"><option>move</option><option>stop</option></select>
        <input id="speed-${id}" type="number" step="0.05" value="0.1" style="width:5rem">
        <button onclick="sendCmd('${id}')">Send</button>
        <span class="err" id="err-${id}"></span>
      </p>`;
    box.appendChild(card);
  }
}
async function act(id, what) {
  const r = await api(`/api/robots/${id}/${what}`, {});
  document.getElementById('err-' + id).textContent = r.error || '';
  refresh();
}
async function sendCmd(id) {
  const name = document.getElementById('cmd-' + id).value;
  const speed = parseFloat(document.getElementById('speed-' + id).value);
  const r = await api(`/api/robots/${id}/command`, {name, parameters: name === 'move' ? {speed} : {}});
  document.getElementById('err-' + id).textContent = r.error || '';
  refresh();
}
refresh();
setInterval(refresh, 3000);
</script>
</body>
</html>
"""


class _Handler(BaseHTTPRequestHandler):
    hub: RobotHub
    loop: asyncio.AbstractEventLoop

    def log_message(self, *_args: Any) -> None:
        pass

    def _send_json(self, code: int, obj: Any) -> None:
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _run(self, coro: Any) -> Any:
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout=10)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/":
            body = _PAGE.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/api/robots":
            states: dict[str, Any] = {}
            for robot_id in self.hub.robot_ids():
                try:
                    states[robot_id] = self._run(self.hub.get_state(robot_id))
                except Exception as exc:  # one bad robot must not break the list
                    states[robot_id] = {"error": str(exc)}
            self._send_json(200, states)
            return
        self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:
        parts = [unquote(p) for p in urlparse(self.path).path.split("/") if p]
        if len(parts) != 4 or parts[0] != "api" or parts[1] != "robots":
            self._send_json(404, {"error": "not found"})
            return
        robot_id, action = parts[2], parts[3]
        try:
            if action == "connect":
                self._run(self.hub.connect(robot_id))
                result = self._run(self.hub.get_state(robot_id))
            elif action == "disconnect":
                self._run(self.hub.disconnect(robot_id))
                result = self._run(self.hub.get_state(robot_id))
            elif action == "command":
                length = int(self.headers.get("Content-Length") or 0)
                data = json.loads(self.rfile.read(length) or b"{}")
                command = RobotCommand(
                    str(data.get("name", "")), dict(data.get("parameters") or {})
                )
                result = self._run(self.hub.execute(robot_id, command))
            else:
                self._send_json(404, {"error": "unknown action"})
                return
        except PermissionError as exc:
            self._send_json(403, {"error": str(exc)})
            return
        except Exception as exc:
            self._send_json(400, {"error": str(exc)})
            return
        self._send_json(200, result)


def serve_dashboard(
    hub: RobotHub, host: str = "0.0.0.0", port: int = 8080
) -> None:
    """Serve the dashboard for ``hub`` until interrupted (Ctrl+C)."""
    loop = asyncio.new_event_loop()
    threading.Thread(target=loop.run_forever, daemon=True).start()
    handler = type("BoundHandler", (_Handler,), {"hub": hub, "loop": loop})
    server = ThreadingHTTPServer((host, port), handler)
    print(f"OpenRobots dashboard: http://localhost:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        loop.call_soon_threadsafe(loop.stop)
