"""An adapter that talks to a robot over MQTT using JSON payloads.

Requires the optional paho-mqtt package:

    python -m pip install "openrobots-framework[mqtt]"

The adapter publishes commands to ``<base_topic>/commands`` and listens
for state updates on ``<base_topic>/state``. Payloads are JSON, e.g. a
command ``{"name": "move", "parameters": {"speed": 0.1}}`` and a state
message ``{"battery": 87, "mode": "idle"}``.
"""

from __future__ import annotations

import json
from typing import Any, Mapping

from .core import RobotCommand


def encode_command(command: RobotCommand) -> str:
    """Serialize a command for publishing."""
    return json.dumps(
        {"name": command.name, "parameters": dict(command.parameters)}
    )


def decode_state(payload: bytes) -> dict[str, Any]:
    """Parse a state payload; non-JSON payloads come back as raw text."""
    text = payload.decode("utf-8", "replace")
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return {"raw": text}
    if isinstance(data, dict):
        return data
    return {"value": data}


class MqttRobot:
    """RobotAdapter for a robot reachable through an MQTT broker."""

    def __init__(
        self,
        host: str,
        port: int = 1883,
        base_topic: str = "openrobots/robot",
        username: str | None = None,
        password: str | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self.base_topic = base_topic.rstrip("/")
        self.username = username
        self.password = password
        self._client: Any = None
        self._state: dict[str, Any] = {}

    @property
    def command_topic(self) -> str:
        return f"{self.base_topic}/commands"

    @property
    def state_topic(self) -> str:
        return f"{self.base_topic}/state"

    async def connect(self) -> None:
        try:
            import paho.mqtt.client as mqtt
        except ImportError as exc:
            raise RuntimeError(
                "paho-mqtt is not installed; install the mqtt extra: "
                'python -m pip install "openrobots-framework[mqtt]"'
            ) from exc

        client = mqtt.Client()
        if self.username is not None:
            client.username_pw_set(self.username, self.password)

        def on_message(_client: Any, _userdata: Any, message: Any) -> None:
            self._state = decode_state(message.payload)

        client.on_message = on_message
        client.connect_async(self.host, self.port)
        client.loop_start()
        client.subscribe(self.state_topic)
        self._client = client

    async def disconnect(self) -> None:
        if self._client is not None:
            self._client.loop_stop()
            self._client.disconnect()
            self._client = None

    async def get_state(self) -> Mapping[str, Any]:
        return {"connected": self._client is not None, **self._state}

    async def execute(self, command: RobotCommand) -> Mapping[str, Any]:
        if self._client is None:
            raise RuntimeError("Connect the MQTT robot before sending commands")
        self._client.publish(self.command_topic, encode_command(command))
        return await self.get_state()
