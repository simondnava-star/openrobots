"""Start the OpenRobots dashboard.

Registers the simulated robot, plus an MQTT robot when the
OPENROBOTS_MQTT_HOST environment variable is set:

    OPENROBOTS_MQTT_HOST=localhost python dashboard.py

Then open http://localhost:8080 in a browser.
"""

import os

from openrobots import CommandPolicy, RobotHub, SimulatedRobot
from openrobots.dashboard import serve_dashboard


def main() -> None:
    policy = CommandPolicy(
        allowed_commands=frozenset({"stop", "move"}),
        numeric_limits={"speed": 0.25},
    )
    hub = RobotHub(policy)
    hub.register("sim", SimulatedRobot())

    mqtt_host = os.environ.get("OPENROBOTS_MQTT_HOST")
    if mqtt_host:
        from openrobots.mqtt_adapter import MqttRobot

        mqtt_port = int(os.environ.get("OPENROBOTS_MQTT_PORT", "1883"))
        hub.register(
            "mqtt-bot",
            MqttRobot(mqtt_host, port=mqtt_port, base_topic="openrobots/mqtt-bot"),
        )

    port = int(os.environ.get("OPENROBOTS_DASHBOARD_PORT", "8080"))
    serve_dashboard(hub, port=port)


if __name__ == "__main__":
    main()
