import unittest

from openrobots import CommandPolicy, RobotCommand, RobotHub, SimulatedRobot


class OpenRobotsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.robot = SimulatedRobot()
        self.hub = RobotHub(
            CommandPolicy(
                allowed_commands=frozenset({"stop", "move"}),
                numeric_limits={"speed": 0.25},
            )
        )
        self.hub.register("demo", self.robot)
        await self.hub.connect("demo")

    async def test_simulator_records_allowed_command(self):
        state = await self.hub.execute(
            "demo", RobotCommand("move", {"speed": 0.1})
        )
        self.assertEqual(state["last_command"], "move")

    async def test_policy_rejects_unlisted_command(self):
        with self.assertRaises(PermissionError):
            await self.hub.execute("demo", RobotCommand("launch"))

    async def test_policy_rejects_out_of_range_value(self):
        with self.assertRaises(ValueError):
            await self.hub.execute(
                "demo", RobotCommand("move", {"speed": 1.0})
            )

    async def test_simulator_requires_connection(self):
        await self.hub.disconnect("demo")
        with self.assertRaises(RuntimeError):
            await self.hub.execute("demo", RobotCommand("stop"))


if __name__ == "__main__":
    unittest.main()
