"""Shared interfaces and policy checks for robot adapters."""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Mapping, Protocol


@dataclass(frozen=True)
class RobotCommand:
    """A normalized command for a robot-specific adapter."""

    name: str
    parameters: Mapping[str, Any] = field(default_factory=dict)


class RobotAdapter(Protocol):
    """Interface implemented by each robot-specific integration."""

    async def connect(self) -> None: ...

    async def disconnect(self) -> None: ...

    async def get_state(self) -> Mapping[str, Any]: ...

    async def execute(self, command: RobotCommand) -> Mapping[str, Any]: ...


@dataclass(frozen=True)
class CommandPolicy:
    """Allow commands explicitly and cap selected numeric parameters.

    The default permits only the universal ``stop`` command. Choose
    parameter limits for the target robot and its units.
    """

    allowed_commands: frozenset[str] = frozenset({"stop"})
    numeric_limits: Mapping[str, float] = field(default_factory=dict)

    def validate(self, command: RobotCommand) -> None:
        if command.name not in self.allowed_commands:
            raise PermissionError(
                f"Command {command.name!r} is not allowed by policy"
            )

        for key, limit in self.numeric_limits.items():
            value = command.parameters.get(key)
            if value is None:
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f"Parameter {key!r} must be a number")
            if not math.isfinite(value) or abs(value) > limit:
                raise ValueError(
                    f"Parameter {key!r} exceeds its configured limit"
                )


class RobotHub:
    """Manage adapters behind a shared command-policy boundary."""

    def __init__(self, policy: CommandPolicy | None = None) -> None:
        self._policy = policy or CommandPolicy()
        self._robots: dict[str, RobotAdapter] = {}

    def register(self, robot_id: str, adapter: RobotAdapter) -> None:
        if not robot_id:
            raise ValueError("robot_id must not be empty")
        if robot_id in self._robots:
            raise ValueError(f"Robot {robot_id!r} is already registered")
        self._robots[robot_id] = adapter

    def _get(self, robot_id: str) -> RobotAdapter:
        try:
            return self._robots[robot_id]
        except KeyError as exc:
            raise KeyError(f"Unknown robot: {robot_id}") from exc

    async def connect(self, robot_id: str) -> None:
        await self._get(robot_id).connect()

    async def disconnect(self, robot_id: str) -> None:
        await self._get(robot_id).disconnect()

    async def get_state(self, robot_id: str) -> Mapping[str, Any]:
        return await self._get(robot_id).get_state()

    async def execute(
        self, robot_id: str, command: RobotCommand
    ) -> Mapping[str, Any]:
        self._policy.validate(command)
        return await self._get(robot_id).execute(command)
