"""A harmless in-memory adapter for development and tests."""

from __future__ import annotations

from typing import Any, Mapping

from .core import RobotCommand


class SimulatedRobot:
    """Record commands in memory without controlling physical hardware."""

    def __init__(self) -> None:
        self.connected = False
        self.last_command: str | None = None

    async def connect(self) -> None:
        self.connected = True

    async def disconnect(self) -> None:
        self.connected = False

    async def get_state(self) -> Mapping[str, Any]:
        return {
            "connected": self.connected,
            "last_command": self.last_command,
        }

    async def execute(self, command: RobotCommand) -> Mapping[str, Any]:
        if not self.connected:
            raise RuntimeError("Connect the simulator before sending commands")
        self.last_command = command.name
        return await self.get_state()
