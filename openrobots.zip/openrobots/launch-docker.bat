@echo off
setlocal
cd /d "%~dp0"

where docker >nul 2>nul
if errorlevel 1 (
    echo Docker was not found. Install Docker Desktop, then try again.
    pause
    exit /b 1
)

docker info >nul 2>nul
if errorlevel 1 (
    echo Docker is installed but not running yet.
    echo Start Docker Desktop, wait until it says it is running, then try again.
    pause
    exit /b 1
)

echo Building the OpenRobots image...
docker build -t openrobots .
if errorlevel 1 (
    echo Build failed.
    pause
    exit /b 1
)

if /i "%~1"=="test" (
    echo Running the tests inside the container...
    docker run --rm openrobots python -m unittest discover -s tests
) else (
    echo Running the demo inside the container...
    docker run --rm openrobots
)

pause
