"""Runnable demo: connect the simulated robot and send it a move command."""

import asyncio

from openrobots import CommandPolicy, RobotCommand, RobotHub, SimulatedRobot


async def main() -> None:
    policy = CommandPolicy(
        allowed_commands=frozenset({"stop", "move"}),
        numeric_limits={"speed": 0.25},
    )
    hub = RobotHub(policy)
    robot = SimulatedRobot()
    hub.register("demo", robot)

    await hub.connect("demo")
    result = await hub.execute("demo", RobotCommand("move", {"speed": 0.1}))
    print(result)
    await hub.disconnect("demo")


if __name__ == "__main__":
    asyncio.run(main())
